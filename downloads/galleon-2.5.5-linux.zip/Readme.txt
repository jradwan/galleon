Galleon
=======

Visit the project home page at http://galleon.sourceforge.net for the latest online documentation.

Send your comments to johnkohl@users.sourceforge.net
Or post them to the HME Developers Corner forum at tivocommunity.com:
http://www.tivocommunity.com/tivo-vb/forumdisplay.php?f=42


Linux install:  use make; see the file "Makefile" in this directory
